class MyConstant{
  static const default_padding = 20.0;
  static const imageUrl="https://placedog.net/800/640?id=209";
  static const banner_image="https://picsum.photos/800/640?random=1";
  static const currentFont = "Poppins";


}