class IndexClass {
  static int index = 0;
}
