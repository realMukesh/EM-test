import 'package:english_madhyam/src/screen/savedQuestion/controller/questionDetailController.dart';
import 'package:english_madhyam/utils/app_colors.dart';
import 'package:english_madhyam/src/widgets/loading.dart';
import 'package:english_madhyam/main.dart';
import 'package:english_madhyam/src/custom/toolbarTitle.dart';

import 'package:english_madhyam/src/widgets/common_textview_widget.dart';
import 'package:english_madhyam/src/widgets/question_widget.dart';
import 'package:english_madhyam/utils/size_utils.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'dart:async';
import 'package:fluttertoast/fluttertoast.dart';
import '../../../custom/rounded_button.dart';
import '../../pages/page/converter.dart';
const String chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';

class SavedQuestionDetailPage extends StatefulWidget {
  static const routeName = "/SavedQuestionDetailPage";
  SavedQuestionDetailPage({Key? key}) : super(key: key);

  @override
  _SavedQuestionDetailPageState createState() =>
      _SavedQuestionDetailPageState();
}

class _SavedQuestionDetailPageState extends State<SavedQuestionDetailPage> {
  TextEditingController reportQuestionController = TextEditingController();
  final QuestionDetailController controller = Get.find();
  final HtmlConverter _htmlConverter = HtmlConverter();

  bool valueUpdated = false;
  int selectedQuestion = 0;
  int selectedOption = 0;
  int selectedOptionIndex = 0;

  @override
  void initState() {
    super.initState();
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: false,
        elevation: 0.0,
        title: const ToolbarTitle(
          title: 'Saved Exam',
        ),
      ),
      body: GetX<QuestionDetailController>(
        builder: (controller) {
          return Stack(
            children: [
              Padding(
                padding: EdgeInsets.all(15.adaptSize),
                child: controller.examDetails.isNotEmpty
                    ? Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const SizedBox(
                            height: 12,
                          ),
                          Expanded(
                            child: SingleChildScrollView(
                              child: Column(
                                children: [
                                  questionWidget(),
                                  optionsWidget(),
                                  const SizedBox(
                                    height: 12,
                                  ),
                                  SizedBox(
                                    height: 150.adaptSize,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      )
                    : const SizedBox(),
              ),
              Align(
                alignment: Alignment.bottomCenter,
                child: bottomButtons(),
              ),
              controller.loading.value
                  ? const Loading()
                  : const SizedBox()
            ],
          );
        },
      ),
    );
  }

  String _printDuration(Duration duration) {
    String twoDigits(int n) => n.toString().padLeft(2, "0");
    return "${twoDigits(duration.inHours)}:${twoDigits(duration.inMinutes.remainder(60))}:${twoDigits(duration.inSeconds.remainder(60))}";
  }

// Checked set colors for question position
  Color getGoToColor(int questionIndex) {
    var questionList = controller.examDetails ?? [];
    if (questionList.isEmpty) return greyColor; // Fallback for empty list

    final question = questionList[questionIndex];
    // Color for marked questions
    if (question.isBookmark == 1) return purpleColor;

    // Color for attempted questions
    if (question.ansType == 1 || question.isAttempt == 1) {
      return lightGreenColor;
    }

    // Default color for unanswered questions
    return hintColor;
    // Default color for unanswered questions
    return hintColor;
  }

  // Initialize question index in a variable and navigate to a specific question
  void goToQuestion(int index) {
    if (index >= 0 && index < controller.examDetails.length) {
      setState(() {
        selectedQuestion = index;
      });
    } else {
      Fluttertoast.showToast(msg: "Question not found");
      cancel();
    }
  }

// Give an answer to a specific question
  Future<void> giveAnswer(int questionIndex, int optionIndex) async {
    if (questionIndex < 0 || questionIndex >= controller.examDetails.length) {
      Fluttertoast.showToast(msg: "Invalid question index");
      cancel();
      return;
    }

    final question = controller.examDetails[questionIndex];
    final options = question.options;

    if (options == null || optionIndex < 0 || optionIndex >= options.length) {
      Fluttertoast.showToast(msg: "Option does not exist");
      cancel();
      return;
    }

    // Reset checked state for all options
    for (var option in options) {
      option.checked = 0;
    }

    // Set the selected option
    options[optionIndex].checked = 1;

    setState(() {
      selectedOption = options[optionIndex].id!;
      question.isSelect = selectedOption;
      selectedOptionIndex = optionIndex;
      question.isAttempt = 1;
      question.ansType = 1;

      print("Selected option ID: ${options[optionIndex].id}");
    });
  }

// Calculate the total number of questions based on a specific condition
  int _getQuestionCount(bool Function(dynamic examQuestion) condition) {
    return controller.examDetails
            ?.where((examQuestion) => condition(examQuestion))
            .length ??
        0;
  }

// Total Answered Number
  int _getAnsweredNumber() {
    return _getQuestionCount((examQuestion) => examQuestion.isAttempt == 1);
  }

// Total Review Question
  int _getReviewNumber() {
    return _getQuestionCount((examQuestion) => examQuestion.isBookmark == 1);
  }

// Total Not Answered Question
  int _getNotAnsweredNumber() {
    return _getQuestionCount((examQuestion) => examQuestion.isAttempt != 1);
  }

// View Next Question
  Future<void> viewNextQuestion({required String option}) async {
    if (selectedQuestion + 1 < controller.examDetails.length) {
      if (selectedOption != 0) {
        if (controller.examDetails[selectedQuestion]
                .options![selectedOptionIndex].id ==
            int.parse(option)) {
          _incrementQuestion();
        } else {
          _showSnackBar("Option not found");
        }
      } else {
        _incrementQuestion();
      }
    } else {
      _resetSelection();
    }
  }

// View Previous Question
  void viewPrevQuestion() {
    if (selectedQuestion > 0) {
      _decrementQuestion();
    } else {
      Fluttertoast.showToast(msg: "No previous question found");
      cancel();
    }
  }

// Remove Answer
  Future<void> removeAnswer(int index) async {
    if (_isValidQuestionIndex(index)) {
      for (var option in controller.examDetails[index].options!) {
        option.checked = 0;
      }
      setState(() {
        controller.examDetails[index]
          ..isAttempt = 0
          ..ansType = 0
          ..isSelect = null;
        _resetSelection();
      });
    } else {
      _showError("Question not found");
    }
  }
// Utility Methods
  void _incrementQuestion() {
    setState(() {
      selectedQuestion++;
      _resetSelection();
    });
  }

  void _decrementQuestion() {
    setState(() {
      selectedQuestion--;
      _resetSelection();
    });
  }

  void _resetSelection() {
    selectedOption = 0;
    selectedOptionIndex = 0;
  }

  bool _isValidQuestionIndex(int index) {
    return index >= 0 && index < controller.examDetails.length;
  }

  void _showError(String message) {
    Fluttertoast.showToast(msg: message);
    cancel();
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

// Build content section of the dialog

// Build row for displaying question status
  Widget _buildRow(String label, String value, Color color) {
    return Container(
      padding: const EdgeInsets.only(bottom: 15),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          CommonTextViewWidget(
              text: label,
              color: color,
              fontSize: 18,
              fontWeight: FontWeight.w500),
          CommonTextViewWidget(
              text: value,
              color: color,
              fontSize: 18,
              fontWeight: FontWeight.w500),
        ],
      ),
    );
  }

  Widget labelCreate(MaterialColor materialColor, String title) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        Container(
          width: 30,
          height: 30,
          decoration: BoxDecoration(
              color: materialColor, borderRadius: BorderRadius.circular(5)),
        ),
        const SizedBox(
          width: 6,
        ),
        CommonTextViewWidgetDarkMode(
          text: title,
          fontSize: 14,
        )
      ],
    );
  }
  //check by mukesh
  Widget questionIndexWidget() {
    return GridView.builder(
      scrollDirection: Axis.vertical,
      physics: const AlwaysScrollableScrollPhysics(),
      shrinkWrap: true,
      itemCount: controller.examDetails.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 4,
          childAspectRatio: 1 / 1,
          mainAxisSpacing: 15,
          crossAxisSpacing: 15),
      itemBuilder: (BuildContext context, int i) {
        var data = controller.examDetails[i];
        return InkWell(
          onTap: () {
            goToQuestion(i);
            Get.back();
          },
          child: Container(
            margin: const EdgeInsets.all(12),
            decoration: BoxDecoration(
                color: getGoToColor(i),
                border: Border.all(
                    color: i != selectedQuestion ? Colors.transparent : green,
                    width: 3),
                borderRadius: BorderRadius.circular(5)),
            width: 30,
            height: 30,
            child: Stack(
              children: [
                Center(
                  child: CommonTextViewWidgetDarkMode(
                    text: (i + 1).toString(),
                    color: whiteColor,
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  //check by mukesh
  Widget questionWidget() {
    return QuestionWidget(
      questionString:
          controller.examDetails[selectedQuestion].eQuestion.toString(),
    );
  }

//check by mukesh
  Widget optionsWidget() {
    return Container(
        margin: const EdgeInsets.only(top: 10),
        padding: const EdgeInsets.only(left: 0, right: 0),
        child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: List.generate(
                controller.examDetails[selectedQuestion].options!.length, (j) {
              return InkWell(
                onTap: () {
                  if (true) {
                    if (controller.loadingQuestion.value) {
                      return;
                    }
                    giveAnswer(selectedQuestion, j);
                  } else {
                    return;
                  }
                },
                child: Container(
                    margin: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                        boxShadow: [
                          BoxShadow(
                            /// check wheter selected option is selected or not
                            color: (controller.examDetails[selectedQuestion]
                                        .options![j].id ==
                                    controller.examDetails[selectedQuestion]
                                        .isSelect)
                                ? greenColor
                                : Colors.grey,
                            offset: const Offset(0.0, 1.0), //(x,y)
                            blurRadius: 4.0,
                          ),
                        ],
                        border: Border.all(
                            color: (controller.examDetails[selectedQuestion]
                                        .options![j].id ==
                                    controller.examDetails[selectedQuestion]
                                        .isSelect)
                                ? greenColor
                                : whiteColor,
                            width: 2),
                        color: whiteColor,
                        borderRadius: BorderRadius.circular(10)),
                    padding: const EdgeInsets.only(
                        left: 10, top: 5, bottom: 5, right: 10),
                    child: Row(
                      children: [
                        Container(
                          decoration: BoxDecoration(
                              color: whiteColor,
                              borderRadius: BorderRadius.circular(50)),
                          width: 30,
                          height: 30,
                          child: Center(
                            child: CommonTextViewWidgetDarkMode(
                                text: chars[j],
                                fontSize: 16,
                                color: blackColor,
                                fontWeight: FontWeight.normal),
                          ),
                        ),
                        (controller.examDetails[selectedQuestion].options![j]
                                    .optionE ==
                                null)
                            ? const Text("")
                            : Expanded(
                                child: Container(
                                    padding: const EdgeInsets.only(
                                        left: 5, right: 5),
                                    child: CommonTextViewWidgetDarkMode(
                                      text: _htmlConverter.removeAllHtmlTags(
                                          controller
                                              .examDetails[selectedQuestion]
                                              .options![j]
                                              .optionE
                                              .toString()),
                                      fontSize: 16,
                                      color: colorSecondary,
                                      fontWeight: FontWeight.normal,
                                    )),
                              ),
                      ],
                    )),
              );
            })));
  }

  Color getGoToOptionColor(int j, int Type) {
    ///correct
    if (controller.examDetails[selectedQuestion]
                .options![j].correct ==
            1 &&
        controller.examDetails[selectedQuestion]
                .options![j].checked ==
            1) {
      return lightGreenColor;
    }

    ///wrong
    else if (controller.examDetails[selectedQuestion].options![j].correct ==
            0 &&
        controller.examDetails[selectedQuestion]
                .options![j].checked ==
            1) {
      return redColor;
    }

    ///default
    else if (controller.examDetails[selectedQuestion].options![j].correct ==
            0 &&
        controller.examDetails[selectedQuestion]
                .options![j].checked ==
            0) {
      ///border color
      if (Type == 1) {
        return greyColor;
      }
      //container color
      else {
        return whiteColor;
      }
    } else if (controller.examDetails[selectedQuestion].options![j].correct ==
        1) {
      return lightGreenColor;
    }
    return Colors.transparent;
  }

//check by mukesh
  Widget bottomButtons() {
    return Container(
        height: 90.adaptSize,
        decoration: BoxDecoration(boxShadow: const [
          BoxShadow(
            color: Colors.grey,
            offset: Offset(0.0, 1.0), //(x,y)
            blurRadius: 4.0,
          ),
        ], color: whiteColor),
        padding: const EdgeInsets.only(top: 0),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 10),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Expanded(
                flex: 4,
                child: (selectedQuestion <= 0)
                    ? Container()
                    : CircularRoundedButton(
                        color: colorSecondary,
                        height: 50.adaptSize,
                        text: "Previous",
                        textSize: 14,
                        press: () {
                          viewPrevQuestion();
                        }),
              ),
              const SizedBox(
                width: 12,
              ),
              Expanded(
                  flex: 3,
                  child: CircularRoundedButton(
                      color: redColor,
                      height: 50.adaptSize,
                      text: "Clear",
                      textSize: 14,
                      press: () {
                        removeAnswer(selectedQuestion);
                      })),
              const SizedBox(
                width: 10,
              ),
              Expanded(
                  flex: 4,
                  child: (selectedQuestion == null
                      ? Container()
                      : Container(
                          margin: const EdgeInsets.all(0),
                          child: CircularRoundedButton(
                              textSize: 14,
                              color: colorPrimary,
                              height: 50.adaptSize,
                              text: selectedQuestion + 1 <
                                      controller.examDetails.length
                                  ? "Next"
                                  : "End",
                              press: () {
                                viewNextQuestion(
                                    option: selectedOption.toString());
                              }))))
            ],
          ),
        ));
  }
}
